export interface Medicine {
  id: string;
  name: string;
  brand: string;
  category: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  inStock: boolean;
  stockQuantity: number;
  prescription: boolean;
  dosage: string;
  manufacturer: string;
  activeIngredient: string;
  sideEffects: string[];
  uses: string[];
  rating: number;
  reviewCount: number;
  discount?: number;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
  medicineCount: number;
}

export interface CartItem {
  medicine: Medicine;
  quantity: number;
}

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  addresses: Address[];
  orders: Order[];
}

export interface Address {
  id: string;
  name: string;
  phone: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  isDefault: boolean;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled";
  address: Address;
  paymentMethod: string;
  orderDate: Date;
  deliveryDate?: Date;
}
