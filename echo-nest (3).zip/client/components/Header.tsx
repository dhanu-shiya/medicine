import { useState } from "react";
import {
  Search,
  User,
  ShoppingCart,
  Menu,
  X,
  Heart,
  MapPin,
  LogOut,
  UserCircle,
  Package,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link } from "react-router-dom";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/contexts/AuthContext";
import { useWishlist } from "@/contexts/WishlistContext";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { state: cartState } = useCart();
  const { state: authState, signOut } = useAuth();
  const { state: wishlistState } = useWishlist();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement search functionality
    console.log("Searching for:", searchQuery);
  };

  return (
    <header className="bg-white shadow-sm border-b sticky top-0 z-50">
      {/* Top bar */}
      <div className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-4">
              <span className="flex items-center">
                <MapPin className="h-4 w-4 mr-1" />
                Free delivery on orders over ₹4000
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <span>24/7 Customer Support</span>
              <span>Track Your Order</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Link
              to="/"
              className="text-2xl font-bold text-primary flex items-center hover:opacity-80 transition-opacity"
            >
              <span className="bg-primary text-primary-foreground px-2 py-1 rounded-lg mr-2">
                ⚕️
              </span>
              MediCare Plus
            </Link>
          </div>

          {/* Search bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-2xl mx-8">
            <form onSubmit={handleSearch} className="relative w-full">
              <Input
                type="text"
                placeholder="Search medicines, brands, or health conditions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-4 pr-12 py-3 text-base"
              />
              <Button
                type="submit"
                size="sm"
                className="absolute right-1 top-1 bottom-1 px-3"
              >
                <Search className="h-4 w-4" />
              </Button>
            </form>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-4">
            {/* Wishlist */}
            <Button
              variant="ghost"
              size="sm"
              className="hidden md:flex relative"
              asChild
            >
              <Link to="/wishlist">
                <Heart className="h-5 w-5 mr-2" />
                Wishlist
                {wishlistState.items.length > 0 && (
                  <Badge
                    variant="destructive"
                    className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs"
                  >
                    {wishlistState.items.length}
                  </Badge>
                )}
              </Link>
            </Button>

            {/* Cart */}
            <Button variant="ghost" size="sm" className="relative" asChild>
              <Link to="/cart">
                <ShoppingCart className="h-5 w-5 mr-2" />
                <span className="hidden md:inline">Cart</span>
                {cartState.itemCount > 0 && (
                  <Badge
                    variant="destructive"
                    className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs"
                  >
                    {cartState.itemCount}
                  </Badge>
                )}
              </Link>
            </Button>

            {/* User menu */}
            {authState.isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center space-x-2"
                  >
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={authState.user?.avatar} />
                      <AvatarFallback>
                        {authState.user?.name?.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden md:inline">
                      {authState.user?.name}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center">
                      <UserCircle className="mr-2 h-4 w-4" />
                      My Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/orders" className="flex items-center">
                      <Package className="mr-2 h-4 w-4" />
                      My Orders
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/wishlist" className="flex items-center">
                      <Heart className="mr-2 h-4 w-4" />
                      Wishlist
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={signOut}
                    className="text-destructive"
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button variant="ghost" size="sm" asChild>
                <Link to="/auth">
                  <User className="h-5 w-5 mr-2" />
                  <span className="hidden md:inline">Sign In</span>
                </Link>
              </Button>
            )}

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile search */}
        <div className="md:hidden mt-4">
          <form onSubmit={handleSearch} className="relative">
            <Input
              type="text"
              placeholder="Search medicines..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-4 pr-12"
            />
            <Button
              type="submit"
              size="sm"
              className="absolute right-1 top-1 bottom-1 px-3"
            >
              <Search className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-secondary">
        <div className="container mx-auto px-4">
          <div className="hidden md:flex space-x-8 py-3">
            <Link
              to="/"
              className="text-secondary-foreground hover:text-primary font-medium transition-colors"
            >
              Home
            </Link>
            <Link
              to="/medicines"
              className="text-secondary-foreground hover:text-primary font-medium transition-colors"
            >
              All Medicines
            </Link>
            <Link
              to="/categories"
              className="text-secondary-foreground hover:text-primary font-medium transition-colors"
            >
              Categories
            </Link>
            <Link
              to="/health-blog"
              className="text-secondary-foreground hover:text-primary font-medium transition-colors"
            >
              Health Blog
            </Link>
            <Link
              to="/contact"
              className="text-secondary-foreground hover:text-primary font-medium transition-colors"
            >
              Contact
            </Link>
          </div>

          {/* Mobile navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 space-y-2">
              <Link
                to="/"
                className="block py-2 text-secondary-foreground hover:text-primary font-medium transition-colors"
              >
                Home
              </Link>
              <Link
                to="/medicines"
                className="block py-2 text-secondary-foreground hover:text-primary font-medium transition-colors"
              >
                All Medicines
              </Link>
              <Link
                to="/categories"
                className="block py-2 text-secondary-foreground hover:text-primary font-medium transition-colors"
              >
                Categories
              </Link>
              <Link
                to="/health-blog"
                className="block py-2 text-secondary-foreground hover:text-primary font-medium transition-colors"
              >
                Health Blog
              </Link>
              <Link
                to="/contact"
                className="block py-2 text-secondary-foreground hover:text-primary font-medium transition-colors"
              >
                Contact
              </Link>
              <div className="border-t pt-4 mt-4">
                <Button variant="ghost" className="w-full justify-start mb-2">
                  <Heart className="h-5 w-5 mr-2" />
                  Wishlist
                </Button>
              </div>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
}
