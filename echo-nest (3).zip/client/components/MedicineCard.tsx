import { Star, ShoppingCart, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Medicine } from "@shared/types";
import { useWishlist } from "@/contexts/WishlistContext";

interface MedicineCardProps {
  medicine: Medicine;
  onAddToCart?: (medicine: Medicine) => void;
}

export default function MedicineCard({
  medicine,
  onAddToCart,
}: MedicineCardProps) {
  const { toggleWishlist, isInWishlist } = useWishlist();

  const handleAddToCart = () => {
    if (onAddToCart) {
      onAddToCart(medicine);
    }
  };

  const handleToggleWishlist = () => {
    toggleWishlist(medicine);
  };

  const isWishlisted = isInWishlist(medicine.id);

  return (
    <Card className="group hover:shadow-lg transition-shadow duration-200 relative overflow-hidden">
      {/* Discount badge */}
      {medicine.discount && (
        <Badge className="absolute top-2 left-2 z-10 bg-destructive text-destructive-foreground">
          {medicine.discount}% OFF
        </Badge>
      )}

      {/* Prescription badge */}
      {medicine.prescription && (
        <Badge className="absolute top-2 right-2 z-10 bg-orange-500 text-white">
          Rx
        </Badge>
      )}

      {/* Wishlist button */}
      <Button
        variant="ghost"
        size="sm"
        className={`absolute top-2 right-2 z-10 p-2 bg-white/80 hover:bg-white ${
          isWishlisted ? "text-red-500" : "text-gray-400"
        }`}
        onClick={handleToggleWishlist}
      >
        <Heart className={`h-4 w-4 ${isWishlisted ? "fill-current" : ""}`} />
      </Button>

      <CardContent className="p-4">
        {/* Medicine Image */}
        <div className="aspect-square mb-4 bg-gray-100 rounded-lg overflow-hidden">
          <img
            src={medicine.image}
            alt={medicine.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
          />
        </div>

        {/* Medicine Info */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Badge variant="secondary" className="text-xs">
              {medicine.brand}
            </Badge>
            {!medicine.inStock && (
              <Badge variant="destructive" className="text-xs">
                Out of Stock
              </Badge>
            )}
          </div>

          <h3 className="font-semibold text-sm line-clamp-2 min-h-[2.5rem]">
            {medicine.name}
          </h3>

          <p className="text-xs text-muted-foreground line-clamp-2">
            {medicine.description}
          </p>

          {/* Dosage */}
          <p className="text-xs font-medium text-primary">{medicine.dosage}</p>

          {/* Rating */}
          <div className="flex items-center space-x-1">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-3 w-3 ${
                    i < Math.floor(medicine.rating)
                      ? "text-yellow-400 fill-current"
                      : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            <span className="text-xs text-muted-foreground">
              {medicine.rating} ({medicine.reviewCount})
            </span>
          </div>

          {/* Price */}
          <div className="flex items-center space-x-2">
            <span className="text-lg font-bold text-primary">
              ₹{medicine.price}
            </span>
            {medicine.originalPrice && (
              <span className="text-sm text-muted-foreground line-through">
                ₹{medicine.originalPrice}
              </span>
            )}
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button
          onClick={handleAddToCart}
          disabled={!medicine.inStock}
          className="w-full"
          size="sm"
        >
          <ShoppingCart className="h-4 w-4 mr-2" />
          {medicine.inStock ? "Add to Cart" : "Out of Stock"}
        </Button>
      </CardFooter>
    </Card>
  );
}
