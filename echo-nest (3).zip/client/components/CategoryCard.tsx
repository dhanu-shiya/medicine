import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Category } from "@shared/types";

interface CategoryCardProps {
  category: Category;
  onClick?: (category: Category) => void;
}

export default function CategoryCard({ category, onClick }: CategoryCardProps) {
  const handleClick = () => {
    if (onClick) {
      onClick(category);
    }
  };

  return (
    <Card
      className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105 bg-gradient-to-br from-primary/5 to-primary/10"
      onClick={handleClick}
    >
      <CardContent className="p-6 text-center">
        <div className="text-4xl mb-4">{category.icon}</div>
        <h3 className="font-semibold text-lg mb-2 text-foreground">
          {category.name}
        </h3>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
          {category.description}
        </p>
        <Badge variant="secondary" className="text-xs">
          {category.medicineCount} items
        </Badge>
      </CardContent>
    </Card>
  );
}
