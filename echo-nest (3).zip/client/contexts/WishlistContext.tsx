import { createContext, useContext, useReducer, ReactNode } from "react";
import { Medicine } from "@shared/types";

interface WishlistState {
  items: Medicine[];
}

type WishlistAction =
  | { type: "ADD_TO_WISHLIST"; payload: Medicine }
  | { type: "REMOVE_FROM_WISHLIST"; payload: string }
  | { type: "CLEAR_WISHLIST" };

const initialState: WishlistState = {
  items: [],
};

function wishlistReducer(
  state: WishlistState,
  action: WishlistAction,
): WishlistState {
  switch (action.type) {
    case "ADD_TO_WISHLIST": {
      const existingItem = state.items.find(
        (item) => item.id === action.payload.id,
      );
      if (existingItem) {
        return state; // Item already in wishlist
      }
      return { items: [...state.items, action.payload] };
    }

    case "REMOVE_FROM_WISHLIST": {
      return {
        items: state.items.filter((item) => item.id !== action.payload),
      };
    }

    case "CLEAR_WISHLIST":
      return initialState;

    default:
      return state;
  }
}

interface WishlistContextType {
  state: WishlistState;
  addToWishlist: (medicine: Medicine) => void;
  removeFromWishlist: (medicineId: string) => void;
  toggleWishlist: (medicine: Medicine) => void;
  isInWishlist: (medicineId: string) => boolean;
  clearWishlist: () => void;
}

const WishlistContext = createContext<WishlistContextType | undefined>(
  undefined,
);

export function WishlistProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(wishlistReducer, initialState);

  const addToWishlist = (medicine: Medicine) => {
    dispatch({ type: "ADD_TO_WISHLIST", payload: medicine });
  };

  const removeFromWishlist = (medicineId: string) => {
    dispatch({ type: "REMOVE_FROM_WISHLIST", payload: medicineId });
  };

  const toggleWishlist = (medicine: Medicine) => {
    const isInList = state.items.some((item) => item.id === medicine.id);
    if (isInList) {
      removeFromWishlist(medicine.id);
    } else {
      addToWishlist(medicine);
    }
  };

  const isInWishlist = (medicineId: string) => {
    return state.items.some((item) => item.id === medicineId);
  };

  const clearWishlist = () => {
    dispatch({ type: "CLEAR_WISHLIST" });
  };

  return (
    <WishlistContext.Provider
      value={{
        state,
        addToWishlist,
        removeFromWishlist,
        toggleWishlist,
        isInWishlist,
        clearWishlist,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (context === undefined) {
    throw new Error("useWishlist must be used within a WishlistProvider");
  }
  return context;
}
