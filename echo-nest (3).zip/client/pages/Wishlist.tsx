import { Heart, ShoppingCart, ArrowLeft, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/Header";
import MedicineCard from "@/components/MedicineCard";
import { useWishlist } from "@/contexts/WishlistContext";
import { useCart } from "@/contexts/CartContext";
import { Link } from "react-router-dom";

export default function Wishlist() {
  const { state: wishlistState, clearWishlist } = useWishlist();
  const { addToCart } = useCart();

  const handleAddToCart = (medicine: any) => {
    addToCart(medicine);
  };

  if (wishlistState.items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />

        <div className="container mx-auto px-4 py-16">
          <div className="text-center max-w-2xl mx-auto">
            <Heart className="mx-auto h-16 w-16 text-muted-foreground mb-6" />
            <h1 className="text-4xl font-bold text-foreground mb-6">
              Your Wishlist is Empty
            </h1>
            <p className="text-muted-foreground text-lg mb-8">
              Save medicines you like to your wishlist. Review them anytime and
              easily move them to your cart.
            </p>
            <Button asChild size="lg">
              <Link to="/medicines">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Browse Medicines
              </Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link to="/medicines">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Continue Shopping
            </Link>
          </Button>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">
                My Wishlist
              </h1>
              <p className="text-muted-foreground">
                {wishlistState.items.length}{" "}
                {wishlistState.items.length === 1 ? "item" : "items"} saved
              </p>
            </div>
            <Button
              variant="outline"
              onClick={clearWishlist}
              className="text-destructive hover:text-destructive"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Clear All
            </Button>
          </div>
        </div>

        {/* Wishlist Items */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {wishlistState.items.map((medicine) => (
            <MedicineCard
              key={medicine.id}
              medicine={medicine}
              onAddToCart={handleAddToCart}
            />
          ))}
        </div>

        {/* Move All to Cart */}
        {wishlistState.items.length > 0 && (
          <div className="mt-8 text-center">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <Button
                  className="w-full"
                  onClick={() => {
                    wishlistState.items.forEach((medicine) =>
                      addToCart(medicine),
                    );
                  }}
                >
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Add All to Cart
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
