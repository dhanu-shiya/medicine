import { useState } from "react";
import {
  Package,
  ArrowLeft,
  Eye,
  RefreshCw,
  Truck,
  CheckCircle,
  XCircle,
  Clock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Header from "@/components/Header";
import { useAuth } from "@/contexts/AuthContext";
import { Link, useNavigate } from "react-router-dom";

// Mock order data - in a real app, this would come from your database
const mockOrders = [
  {
    id: "ORD-001",
    date: "2024-01-15",
    status: "delivered",
    total: 7471,
    itemCount: 3,
    items: [
      { name: "Ibuprofen 400mg", quantity: 2, price: 1079 },
      { name: "Vitamin D3 2000 IU", quantity: 1, price: 1659 },
      { name: "Omega-3 Fish Oil", quantity: 1, price: 2739 },
    ],
    address: "123 Main St, Anytown, ST 12345",
    trackingNumber: "TRK123456789",
  },
  {
    id: "ORD-002",
    date: "2024-01-20",
    status: "shipped",
    total: 3783,
    itemCount: 2,
    items: [
      { name: "Acetaminophen 500mg", quantity: 1, price: 829 },
      { name: "Multivitamin Complete", quantity: 1, price: 1909 },
    ],
    address: "123 Main St, Anytown, ST 12345",
    trackingNumber: "TRK987654321",
  },
  {
    id: "ORD-003",
    date: "2024-01-25",
    status: "processing",
    total: 13026,
    itemCount: 4,
    items: [
      { name: "Atorvastatin 20mg", quantity: 1, price: 45.99 },
      { name: "Metformin 500mg", quantity: 2, price: 19.99 },
      { name: "Probiotics Daily", quantity: 1, price: 29.99 },
    ],
    address: "123 Main St, Anytown, ST 12345",
    trackingNumber: null,
  },
];

export default function Orders() {
  const { state: authState } = useAuth();
  const navigate = useNavigate();
  const [statusFilter, setStatusFilter] = useState<string>("all");

  // Redirect if not authenticated
  if (!authState.isAuthenticated) {
    navigate("/auth");
    return null;
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "delivered":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "shipped":
        return <Truck className="h-4 w-4 text-blue-500" />;
      case "processing":
        return <Clock className="h-4 w-4 text-orange-500" />;
      case "cancelled":
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Package className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-800";
      case "shipped":
        return "bg-blue-100 text-blue-800";
      case "processing":
        return "bg-orange-100 text-orange-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const filteredOrders =
    statusFilter === "all"
      ? mockOrders
      : mockOrders.filter((order) => order.status === statusFilter);

  if (mockOrders.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />

        <div className="container mx-auto px-4 py-16">
          <div className="text-center max-w-2xl mx-auto">
            <Package className="mx-auto h-16 w-16 text-muted-foreground mb-6" />
            <h1 className="text-4xl font-bold text-foreground mb-6">
              No Orders Yet
            </h1>
            <p className="text-muted-foreground text-lg mb-8">
              You haven't placed any orders yet. Start shopping to see your
              order history here.
            </p>
            <Button asChild size="lg">
              <Link to="/medicines">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Start Shopping
              </Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link to="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Link>
          </Button>

          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">
                My Orders
              </h1>
              <p className="text-muted-foreground">
                Track and manage your medicine orders
              </p>
            </div>

            {/* Filter */}
            <div className="flex items-center space-x-4">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Orders</SelectItem>
                  <SelectItem value="processing">Processing</SelectItem>
                  <SelectItem value="shipped">Shipped</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Orders List */}
        <div className="space-y-6">
          {filteredOrders.map((order) => (
            <Card key={order.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div>
                      <CardTitle className="text-lg">
                        Order {order.id}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">
                        Placed on {new Date(order.date).toLocaleDateString()}
                      </p>
                    </div>
                    <Badge className={getStatusColor(order.status)}>
                      <div className="flex items-center space-x-1">
                        {getStatusIcon(order.status)}
                        <span className="capitalize">{order.status}</span>
                      </div>
                    </Badge>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-semibold">
                      ₹{order.total.toLocaleString("en-IN")}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {order.itemCount} item{order.itemCount > 1 ? "s" : ""}
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Order Items */}
                <div>
                  <h4 className="font-medium mb-2">Items</h4>
                  <div className="space-y-2">
                    {order.items.map((item, index) => (
                      <div
                        key={index}
                        className="flex justify-between items-center text-sm"
                      >
                        <div className="flex-1">
                          <span className="font-medium">{item.name}</span>
                          <span className="text-muted-foreground ml-2">
                            x{item.quantity}
                          </span>
                        </div>
                        <span className="font-medium">
                          ₹
                          {(item.price * item.quantity).toLocaleString("en-IN")}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Delivery Info */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-1">Delivery Address</h4>
                    <p className="text-sm text-muted-foreground">
                      {order.address}
                    </p>
                  </div>

                  {order.trackingNumber && (
                    <div>
                      <h4 className="font-medium mb-1">Tracking Number</h4>
                      <p className="text-sm text-muted-foreground font-mono">
                        {order.trackingNumber}
                      </p>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex space-x-2 pt-2">
                  <Button variant="outline" size="sm">
                    <Eye className="mr-2 h-4 w-4" />
                    View Details
                  </Button>

                  {order.status === "delivered" && (
                    <Button variant="outline" size="sm">
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Reorder
                    </Button>
                  )}

                  {order.trackingNumber && (
                    <Button variant="outline" size="sm">
                      <Truck className="mr-2 h-4 w-4" />
                      Track Package
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredOrders.length === 0 && statusFilter !== "all" && (
          <div className="text-center py-12">
            <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">
              No {statusFilter} orders
            </h3>
            <p className="text-muted-foreground mb-4">
              You don't have any {statusFilter} orders at the moment.
            </p>
            <Button variant="outline" onClick={() => setStatusFilter("all")}>
              View All Orders
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
