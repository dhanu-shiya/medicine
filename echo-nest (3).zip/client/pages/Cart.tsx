import { useState } from "react";
import {
  Minus,
  Plus,
  Trash2,
  ShoppingCart,
  ArrowLeft,
  CreditCard,
  Truck,
  Shield,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Header from "@/components/Header";
import { useCart } from "@/contexts/CartContext";
import { Link } from "react-router-dom";

export default function Cart() {
  const {
    state: cartState,
    removeFromCart,
    updateQuantity,
    clearCart,
  } = useCart();
  const [promoCode, setPromoCode] = useState("");
  const [appliedPromo, setAppliedPromo] = useState<{
    code: string;
    discount: number;
  } | null>(null);

  const shipping = cartState.total >= 4000 ? 0 : 149;
  const tax = cartState.total * 0.08; // 8% tax
  const promoDiscount = appliedPromo
    ? cartState.total * appliedPromo.discount
    : 0;
  const finalTotal = cartState.total + shipping + tax - promoDiscount;

  const handleQuantityChange = (medicineId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(medicineId);
    } else {
      updateQuantity(medicineId, newQuantity);
    }
  };

  const applyPromoCode = () => {
    // Simple promo code logic - in real app this would be server-side
    const promoCodes: { [key: string]: number } = {
      SAVE10: 0.1,
      HEALTH20: 0.2,
      FIRST15: 0.15,
    };

    if (promoCodes[promoCode.toUpperCase()]) {
      setAppliedPromo({
        code: promoCode.toUpperCase(),
        discount: promoCodes[promoCode.toUpperCase()],
      });
      setPromoCode("");
    }
  };

  if (cartState.items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />

        <div className="container mx-auto px-4 py-16">
          <div className="text-center max-w-2xl mx-auto">
            <ShoppingCart className="mx-auto h-16 w-16 text-muted-foreground mb-6" />
            <h1 className="text-4xl font-bold text-foreground mb-6">
              Your Cart is Empty
            </h1>
            <p className="text-muted-foreground text-lg mb-8">
              Looks like you haven't added any medicines to your cart yet.
              Explore our wide selection of quality medicines and health
              products.
            </p>
            <div className="space-y-4">
              <Button asChild size="lg">
                <Link to="/medicines">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Browse Medicines
                </Link>
              </Button>
              <div className="flex items-center justify-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Shield className="h-4 w-4 mr-1" />
                  Genuine Products
                </div>
                <div className="flex items-center">
                  <Truck className="h-4 w-4 mr-1" />
                  Free Delivery over ₹4000
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Shopping Cart
          </h1>
          <p className="text-muted-foreground">
            {cartState.itemCount} {cartState.itemCount === 1 ? "item" : "items"}{" "}
            in your cart
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Cart Items</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearCart}
                  className="text-destructive hover:text-destructive"
                >
                  Clear Cart
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                {cartState.items.map((item) => (
                  <div
                    key={item.medicine.id}
                    className="flex items-center space-x-4 p-4 border rounded-lg"
                  >
                    {/* Medicine Image */}
                    <div className="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden shrink-0">
                      <img
                        src={item.medicine.image}
                        alt={item.medicine.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Medicine Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold text-sm line-clamp-2">
                            {item.medicine.name}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {item.medicine.brand} • {item.medicine.dosage}
                          </p>
                          {item.medicine.prescription && (
                            <Badge variant="outline" className="mt-1 text-xs">
                              Prescription Required
                            </Badge>
                          )}
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFromCart(item.medicine.id)}
                          className="text-destructive hover:text-destructive shrink-0 ml-2"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      {/* Quantity and Price */}
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() =>
                              handleQuantityChange(
                                item.medicine.id,
                                item.quantity - 1,
                              )
                            }
                            className="h-8 w-8 p-0"
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-12 text-center text-sm font-medium">
                            {item.quantity}
                          </span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() =>
                              handleQuantityChange(
                                item.medicine.id,
                                item.quantity + 1,
                              )
                            }
                            className="h-8 w-8 p-0"
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">
                            ₹
                            {(
                              item.medicine.price * item.quantity
                            ).toLocaleString("en-IN")}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            ₹{item.medicine.price.toLocaleString("en-IN")} each
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Continue Shopping */}
            <div className="flex justify-between items-center">
              <Button variant="outline" asChild>
                <Link to="/medicines">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Continue Shopping
                </Link>
              </Button>
            </div>
          </div>

          {/* Order Summary */}
          <div className="space-y-6">
            {/* Promo Code */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Promo Code</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex space-x-2">
                  <Input
                    placeholder="Enter promo code"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                  />
                  <Button onClick={applyPromoCode} disabled={!promoCode.trim()}>
                    Apply
                  </Button>
                </div>
                {appliedPromo && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-green-600">
                      Code "{appliedPromo.code}" applied
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setAppliedPromo(null)}
                    >
                      Remove
                    </Button>
                  </div>
                )}
                <div className="text-xs text-muted-foreground">
                  Try: SAVE10, HEALTH20, FIRST15
                </div>
              </CardContent>
            </Card>

            {/* Order Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal ({cartState.itemCount} items)</span>
                    <span>₹{cartState.total.toLocaleString("en-IN")}</span>
                  </div>

                  {appliedPromo && (
                    <div className="flex justify-between text-green-600">
                      <span>Discount ({appliedPromo.code})</span>
                      <span>-₹{promoDiscount.toLocaleString("en-IN")}</span>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>
                      {shipping === 0 ? (
                        <span className="text-green-600">Free</span>
                      ) : (
                        `₹${shipping.toLocaleString("en-IN")}`
                      )}
                    </span>
                  </div>

                  <div className="flex justify-between">
                    <span>Tax</span>
                    <span>₹{tax.toLocaleString("en-IN")}</span>
                  </div>
                </div>

                <Separator />

                <div className="flex justify-between text-lg font-semibold">
                  <span>Total</span>
                  <span>₹{finalTotal.toLocaleString("en-IN")}</span>
                </div>

                {cartState.total < 50 && (
                  <div className="text-sm text-muted-foreground bg-blue-50 p-3 rounded-lg">
                    Add ₹{(4000 - cartState.total).toLocaleString("en-IN")} more
                    for free shipping!
                  </div>
                )}

                <Button className="w-full" size="lg" asChild>
                  <Link to="/checkout">
                    <CreditCard className="mr-2 h-4 w-4" />
                    Proceed to Checkout
                  </Link>
                </Button>

                <div className="space-y-2 text-xs text-muted-foreground">
                  <div className="flex items-center">
                    <Shield className="h-3 w-3 mr-1" />
                    Secure checkout with SSL encryption
                  </div>
                  <div className="flex items-center">
                    <Truck className="h-3 w-3 mr-1" />
                    Free delivery on orders over ₹4000
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Trust Indicators */}
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-3 text-sm">
                  <div className="flex items-center">
                    <Shield className="h-4 w-4 mr-2 text-primary" />
                    <span>100% Genuine Medicines</span>
                  </div>
                  <div className="flex items-center">
                    <Truck className="h-4 w-4 mr-2 text-primary" />
                    <span>Fast & Secure Delivery</span>
                  </div>
                  <div className="flex items-center">
                    <CreditCard className="h-4 w-4 mr-2 text-primary" />
                    <span>Secure Payment Options</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
